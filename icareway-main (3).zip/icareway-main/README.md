# icareway


---

# Process Mining Dashboard

## Overview

This web application provides a **Process Mining dashboard** for visualizing patient workflows in a hospital setting. It allows users to filter cases, select specific dates, and analyze performance and frequency of transitions between activities. Key features include:

* Interactive **Process Model (DFG)** visualization.
* **Performance analysis** with color-coded thresholds.
* **Frequency-based filtering** of transitions.
* **KPI display**: average, minimum, and maximum case durations.
* Editable **time thresholds** for each transition.

The application is built with **Flask**, **PM4Py**, **Graphviz**, and **Bootstrap** for the front-end.

---

## File Structure
```
project/
│
├─ app.py                     # Main Flask app: handles routes, data filtering, DFG generation, KPIs
├─ data.xlsx                  # Input Excel file with patient cases (CASEID, ACTIVITYNAME, ACTIVITYTIME)
├─ templates/                 # HTML templates for Flask pages
│   ├─ filter.html            # Main dashboard: filters, DFG image, KPIs, threshold table
│   ├─ Departments.html       # Departments page
│   ├─ ChronicCare.html       # Chronic care monitoring page
│   ├─ TreatmentCosts.html    # Treatment costs page
│   ├─ AdherenceScale.html    # Adherence scale page
│   └─ SmartAssistant.html    # Smart assistant/chatbot page
│
├─ static/                # Static assets: CSS, images, generated DFGs
│   ├─ CSS/
│   │   ├─ processModel.css       # Styles for filter.html (dashboard)
│   │   ├─ Departments.css        # Styles for Departments.html
│   │   ├─ ChronicCare.css        # Styles for ChronicCare.html
│   │   ├─ TreatmentCosts.css     # Styles for TreatmentCosts.html
│   │   ├─ AdherenceScale.css     # Styles for AdherenceScale.html
│   │   └─ SmartAssistant.css     # Styles for SmartAssistant.html
│   ├─ images/
│   │   ├─ adherence/     # Icons/images for AdherenceScale page
│   │   ├─ assistant/     # Images for SmartAssistant page
│   │   ├─ chronic/       # Images for ChronicCare page
│   │   ├─ departments/   # Images for Departments page
│   │   ├─ header/        # Header logos and icons
│   │   ├─ indexImg/      # Homepage/main index images
│   │   ├─ navigation/    # Navigation icons for menu/buttons
│   │   └─ treatment/     # Images for TreatmentCosts page
│   └─                    # Automatically generated DFG images (frequency/performance)
└─ README.md        # Project documentation
```

---

## Requirements

* Python >= 3.9
* Flask
* pandas
* pm4py
* graphviz
* Bootstrap 5
* jQuery
* Select2

Install dependencies via pip:

```bash
pip install flask pandas pm4py graphviz
```

**Note:** Make sure Graphviz is installed on your system for DFG generation.

---

## Usage

1. **Run the Flask server:**

```bash
python app.py
```

2. **Open your browser** and navigate to:

```
http://127.0.0.1:5005/
```

3. **Dashboard Features:**

* **Filter by model type:** Choose `Frequency` or `Performance`.
* **Select case:** Choose a specific case or `All Cases`.
* **Select days:** Multi-select to filter by dates.
* **Hide edges below frequency:** Only shows transitions above a threshold.
* **Update thresholds:** Edit thresholds for each transition and see the edge color change if exceeded.

---

## How It Works

1. **Data Loading:** Reads `data.xlsx` and renames columns to match `case_id`, `activity`, and `timestamp`.
2. **Filtering:** Users can filter by case, dates, and minimum edge frequency.
3. **DFG Generation:**
   * **Frequency-based:** Generates the process model based on transition counts.
   * **Performance-based:** Generates a process model where edges are color-coded according to average time vs threshold.
4. **KPI Calculation:** Computes average, min, and max case durations.
5. **Threshold Table:** Allows users to update edge thresholds interactively.

---

## Notes

- In some cases, there might be an issue with linking the data file (`data.xlsx`).  
- If this happens, you can solve it by fixing the path dynamically:  
  ```python
  import os
  file_path = os.path.join(os.path.dirname(__file__), "data.xlsx")
  ```
