from flask import Flask, render_template, request, redirect, url_for, session
import os
import warnings
import math
import pandas as pd
import pm4py
import graphviz
from pm4py.algo.discovery.heuristics import algorithm as heu_miner
from pm4py.visualization.heuristics_net import visualizer as hn_vis
from pm4py.algo.discovery.inductive import algorithm as inductive_miner
from pm4py.visualization.petri_net import visualizer as pn_vis
import pandas as pd
import json

# =========================================================
# ===============  SECTION: DATA PREPARATION  =============
# =========================================================
# Read the original Excel file
df_raw = pd.read_excel("data.xlsx")

# Modify ACTIVITYNAME by prefixing LOCATION for 'WR' rows
df_raw['ACTIVITYNAME'] = df_raw.apply(
    lambda row: f"{row['LOCATION']}-{row['ACTIVITYNAME']}" if row['LOCATION'] == 'WR' else row['ACTIVITYNAME'],
    axis=1
)

# Save the updated file that the app uses
UPDATED_FILE = "data_updated.xlsx"
df_raw.to_excel(UPDATED_FILE, index=False)

# =========================================================
# ==============  SECTION: GLOBAL SETTINGS  ===============
# =========================================================
# Hide "Noshow" from visual models by default (KPI still computed on original df)
HIDE_NOSHOW = True

def _is_noshow(x):
    return str(x).strip().lower().replace(" ", "").replace("_", "") == "noshow"

def _drop_noshow(df):
    if "activity" in df.columns:
        return df[~df["activity"].apply(_is_noshow)].copy()
    return df

# =========================================================
# ==================  SECTION: FLASK APP  =================
# =========================================================
app = Flask(__name__)

# Use absolute paths to ensure stability across different run locations
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)

app.secret_key = "CHANGE_ME_SECURE_KEY"  # Required for session management (change to secure key)

# =========================================================
# =======  SECTION: THRESHOLD OVERRIDES PERSISTENCE  ======
# =========================================================
# In-memory store of user overrides for (source_activity, target_activity) -> threshold_minutes
THRESHOLD_OVERRIDES = {}

# JSON file to persist overrides across restarts
OVERRIDES_PATH = os.path.join(STATIC_DIR, "threshold_overrides.json")
print("Overrides file path =>", OVERRIDES_PATH)

def load_overrides():
    """
    Load threshold overrides from JSON file into THRESHOLD_OVERRIDES.
    Supports both list format (preferred) and some legacy dict formats for safety.
    """
    global THRESHOLD_OVERRIDES
    try:
        if os.path.exists(OVERRIDES_PATH):
            with open(OVERRIDES_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                loaded = {}

                # Preferred format: list of {"src":..., "tgt":..., "thr":...}
                if isinstance(data, list):
                    for item in data:
                        s = item.get("src")
                        t = item.get("tgt")
                        v = item.get("thr")
                        if s is not None and t is not None and v is not None:
                            loaded[(str(s), str(t))] = float(v)

                # Back-compat format: dict with "src||tgt" keys
                elif isinstance(data, dict):
                    for k, v in data.items():
                        if isinstance(k, str) and "||" in k:
                            s, t = k.split("||", 1)
                            loaded[(s, t)] = float(v)
                        # Very old/rare: dict with tuple-like string keys "(A, B)"
                        elif isinstance(k, str) and k.startswith("(") and k.endswith(")"):
                            try:
                                # naive parse: "(A, B)" -> ["A", " B"]
                                parts = k[1:-1].split(",", 1)
                                s = parts[0].strip()
                                t = parts[1].strip() if len(parts) > 1 else ""
                                loaded[(s, t)] = float(v)
                            except Exception:
                                pass

                THRESHOLD_OVERRIDES = loaded
    except Exception as e:
        print("Failed to load overrides:", e)


def save_overrides():
    """
    Persist THRESHOLD_OVERRIDES to JSON file.
    We store as a list of records for JSON-friendliness.
    """
    try:
        data = [{"src": s, "tgt": t, "thr": float(v)} for (s, t), v in THRESHOLD_OVERRIDES.items()]
        with open(OVERRIDES_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("Failed to save overrides:", e)


def apply_overrides_to_thresholds(thresholds: dict):
    """
    Apply stored overrides to a freshly built thresholds dict.
    This uses case/space-insensitive matching to guard against minor label variations.

    thresholds: dict[(src, tgt) -> float]
    returns: thresholds after applying overrides in-place, and also returns it for convenience.
    """
    def _norm(x):  # normalize for robust comparison
        return str(x).strip().lower()

    # Map of normalized (src, tgt) from current graph to the original (src, tgt)
    key_map = {(_norm(s), _norm(t)): (s, t) for (s, t) in thresholds.keys()}

    # Apply overrides by matching normalized keys
    for (s_over, t_over), val in THRESHOLD_OVERRIDES.items():
        k_norm = (_norm(s_over), _norm(t_over))
        if k_norm in key_map:
            real_key = key_map[k_norm]
            thresholds[real_key] = float(val)

    return thresholds

# Load overrides once on startup
load_overrides()

# =========================================================
# ===============  SECTION: APP UTILITIES  ================
# =========================================================
def clean_and_sample(df, sample_size=None):
    """
    Cleaning routine:
    - Drop rows with missing case_id, activity, or timestamp
    - Drop duplicate events by (case_id, activity, timestamp)
    - Optionally sample first `sample_size` rows
    """
    df = (
        df.dropna(subset=["case_id", "activity", "timestamp"])
          .drop_duplicates(subset=["case_id", "activity", "timestamp"])
    )
    if sample_size is not None:
        df = df.head(sample_size)
    return df

def compute_transition_stats(df):
    """
    Compute transition-level statistics:
    Returns: activities, counts, avg_minutes, p75_map, edges
    - counts/avg_minutes/p75_map keyed by (source_activity, target_activity)
    """
    if df.empty:
        return [], {}, {}, {}, []

    df = df.sort_values(["case_id", "timestamp"])
    df["next_activity"] = df.groupby("case_id")["activity"].shift(-1)
    df["next_timestamp"] = df.groupby("case_id")["timestamp"].shift(-1)

    trans = df.dropna(subset=["next_activity", "next_timestamp"]).copy()
    if trans.empty:
        return [], {}, {}, {}, []

    trans["delta_min"] = (trans["next_timestamp"] - trans["timestamp"]).dt.total_seconds() / 60.0

    grouped = trans.groupby(["activity", "next_activity"])["delta_min"]
    stats = grouped.agg(
        count="size",
        avg="mean",
        p75=lambda x: x.quantile(0.75)
    ).reset_index()

    counts = {(r["activity"], r["next_activity"]): int(r["count"]) for _, r in stats.iterrows()}
    avg_min = {(r["activity"], r["next_activity"]): float(r["avg"]) for _, r in stats.iterrows()}
    p75_map = {(r["activity"], r["next_activity"]): float(r["p75"]) for _, r in stats.iterrows()}
    activities = pd.unique(pd.concat([df["activity"], df["next_activity"].dropna()]))
    edges = list(counts.keys())
    return activities, counts, avg_min, p75_map, edges

def build_thresholds_for_all_edges(edges):
    """
    Build thresholds for all edges using a fully manual mapping (no p75_map).
    Result: dict mapping (src, tgt) -> threshold_minutes (float), clamped to [5, 180].
    """
    manual_rules = {
        # ================== Bed Assignment ==================
        ("Bed Assignment", "Bed Assignment"): 30.0,
        ("Bed Assignment", "CheckIn"): 20.0,
        ("Bed Assignment", "CheckOut"): 15.0,
        ("Bed Assignment", "Medicine Given"): 60.0,
        ("Bed Assignment", "Pre-Check"): 45.0,
        ("Bed Assignment", "Vitals"): 25.0,
        ("Bed Assignment", "WR-Bed Assignment"): 40.0,

        # ================== CheckIn ==================
        ("CheckIn", "Bed Assignment"): 45.0,
        ("CheckIn", "CheckIn"): 30.0,
        ("CheckIn", "CheckOut"): 20.0,
        ("CheckIn", "Medicine Given"): 60.0,
        ("CheckIn", "Pre-Check"): 30.0,
        ("CheckIn", "Vitals"): 25.0,
        ("CheckIn", "WR-Bed Assignment"): 50.0,

        # ================== CheckOut ==================
        ("CheckOut", "Bed Assignment"): 15.0,
        ("CheckOut", "CheckIn"): 20.0,
        ("CheckOut", "Medicine Given"): 10.0,
        ("CheckOut", "Post-Check"): 15.0,
        ("CheckOut", "Pre-Check"): 20.0,
        ("CheckOut", "Vitals"): 25.0,
        ("CheckOut", "WR-Bed Assignment"): 30.0,

        # ================== Medicine Given ==================
        ("Medicine Given", "Bed Assignment"): 60.0,
        ("Medicine Given", "CheckIn"): 40.0,
        ("Medicine Given", "CheckOut"): 30.0,
        ("Medicine Given", "Medicine Given"): 30.0,
        ("Medicine Given", "Post-Check"): 30.0,
        ("Medicine Given", "Pre-Check"): 35.0,
        ("Medicine Given", "Vitals"): 20.0,
        ("Medicine Given", "WR-Bed Assignment"): 60.0,

        # ================== Noshow ==================
        ("Noshow", "Bed Assignment"): 30.0,
        ("Noshow", "CheckIn"): 5.0,
        ("Noshow", "Medicine Given"): 5.0,
        ("Noshow", "Noshow"): 30.0,
        ("Noshow", "Vitals"): 5.0,

        # ================== Post-Check ==================
        ("Post-Check", "Bed Assignment"): 40.0,
        ("Post-Check", "CheckIn"): 25.0,
        ("Post-Check", "CheckOut"): 20.0,
        ("Post-Check", "Medicine Given"): 25.0,
        ("Post-Check", "Post-Check"): 30.0,
        ("Post-Check", "Pre-Check"): 25.0,
        ("Post-Check", "Vitals"): 20.0,
        ("Post-Check", "WR-Bed Assignment"): 45.0,

        # ================== Pre-Check ==================
        ("Pre-Check", "Bed Assignment"): 50.0,
        ("Pre-Check", "CheckIn"): 30.0,
        ("Pre-Check", "CheckOut"): 25.0,
        ("Pre-Check", "Medicine Given"): 40.0,
        ("Pre-Check", "Noshow"): 10.0,
        ("Pre-Check", "Post-Check"): 25.0,
        ("Pre-Check", "Pre-Check"): 30.0,
        ("Pre-Check", "Vitals"): 15.0,
        ("Pre-Check", "WR-Bed Assignment"): 55.0,

        # ================== Vitals ==================
        ("Vitals", "Bed Assignment"): 45.0,
        ("Vitals", "CheckIn"): 20.0,
        ("Vitals", "CheckOut"): 20.0,
        ("Vitals", "Medicine Given"): 30.0,
        ("Vitals", "Post-Check"): 20.0,
        ("Vitals", "Pre-Check"): 15.0,
        ("Vitals", "Vitals"): 15.0,
        ("Vitals", "WR-Bed Assignment"): 50.0,

        # ================== WR-Bed Assignment ==================
        ("WR-Bed Assignment", "Bed Assignment"): 90.0,
        ("WR-Bed Assignment", "CheckIn"): 40.0,
        ("WR-Bed Assignment", "CheckOut"): 35.0,
        ("WR-Bed Assignment", "Medicine Given"): 60.0,
        ("WR-Bed Assignment", "Noshow"): 10.0,
        ("WR-Bed Assignment", "Pre-Check"): 45.0,
        ("WR-Bed Assignment", "Vitals"): 30.0,
        ("WR-Bed Assignment", "WR-Bed Assignment"): 60.0,
    }

    thresholds = {}
    for (src, tgt) in edges:
        value = manual_rules.get((src, tgt), 30)
        value = float(value)
        value = max(5.0, min(180.0, value))
        thresholds[(src, tgt)] = value

    return thresholds

# =========================================================
# ============  SECTION: DFG / GRAPH GENERATION  =========
# =========================================================
def generate_dfg_file(df, variant="frequency", sample_size=None, min_edge_freq=5, selected_case="all"):
    """
    Generate a DFG image file (PNG) based on the dataframe.
    - variant: "frequency" or "performance"
    - min_edge_freq: minimum frequency to include edge
    """
    warnings.simplefilter(action='ignore', category=pd.errors.SettingWithCopyWarning)

    df_clean = clean_and_sample(df, sample_size)

    # Drop "Noshow" for visualization if enabled (KPIs are computed elsewhere on original df)
    if HIDE_NOSHOW:
        df_clean = _drop_noshow(df_clean)

    if df_clean.empty:
        return f"{STATIC_DIR}/empty.png"

    # pm4py formatted log
    log = pm4py.format_dataframe(df_clean, case_id="case_id", activity_key="activity", timestamp_key="timestamp")

    os.makedirs(STATIC_DIR, exist_ok=True)

    if variant == "performance":
        # Build stats for performance-based DFG
        activities, counts, avg_minutes, p75_map, edges = compute_transition_stats(df_clean)
        thresholds = build_thresholds_for_all_edges(edges)
        thresholds = apply_overrides_to_thresholds(thresholds)  # <= apply persisted overrides

        min_edge_freq = int(min_edge_freq)
        filtered_edges = [e for e in edges if counts.get(e, 0) >= min_edge_freq]

        # Remove any edges including Noshow (safety)
        filtered_edges = [e for e in filtered_edges if not (_is_noshow(e[0]) or _is_noshow(e[1]))]

        # Collect nodes
        nodes_to_keep = set()
        for (s, t) in filtered_edges:
            nodes_to_keep.add(str(s))
            nodes_to_keep.add(str(t))

        # Handle empty graph
        if not filtered_edges:
            dot = graphviz.Digraph("heuristics_performance", format="png")
            dot.node("EMPTY", "No edges after filtering", shape="box", style="rounded,filled",
                     fillcolor="#fff3cd", color="#856404")
            filename = f"{STATIC_DIR}/heuristics_performance"
            dot.render(filename, cleanup=True)
            return f"{filename}.png"

        # Identify start/end nodes on the cleaned df
        df_sorted = df_clean.sort_values(["case_id", "timestamp"])
        start_nodes = sorted(set(df_sorted.groupby("case_id").first()["activity"].astype(str)).intersection(nodes_to_keep))
        end_nodes = sorted(set(df_sorted.groupby("case_id").last()["activity"].astype(str)).intersection(nodes_to_keep))

        # Graphviz styling (horizontal flow)
        dot = graphviz.Digraph("heuristics_performance", format="png")
        dot.attr(rankdir="LR", splines="spline", overlap="false", fontname="Arial", fontsize="12")
        dot.attr("node", shape="box", style="filled,rounded", fillcolor="#add8e6", color="#3b5998",
                 fontname="Arial", fontsize="14")

        for act in sorted(nodes_to_keep):
            dot.node(act, act)

        # Start/End helper nodes
        dot.node("__START__", "Start", shape="circle", style="filled", fillcolor="#e8f5e9", color="#66bb6a", fontsize="12")
        dot.node("__END__", "End", shape="circle", style="filled", fillcolor="#ffebee", color="#ef5350", fontsize="12")

        for a in start_nodes:
            dot.edge("__START__", a, style="dashed", color="#9e9e9e", arrowsize="0.7")
        for a in end_nodes:
            dot.edge(a, "__END__", style="dashed", color="#9e9e9e", arrowsize="0.7")

        def _fmt_minutes(m):
            try:
                m = float(m)
            except:
                return ""
            return f"{m/60:.1f}h" if m >= 60 else f"{m:.0f}m"

        # Edge width scaling by frequency
        c_vals = [counts.get(e, 0) for e in filtered_edges]
        c_min, c_max = min(c_vals), max(c_vals)

        def _scale_penwidth(c):
            if c_max == c_min:
                return "1.6"
            norm = (c - c_min) / (c_max - c_min + 1e-9)
            return f"{1.0 + 2.5*norm:.2f}"

        # Draw edges with color by threshold comparison
        for (src, tgt) in sorted(filtered_edges):
            s, t = str(src), str(tgt)
            avg = avg_minutes.get((src, tgt))
            thr = thresholds.get((src, tgt))
            lbl = _fmt_minutes(avg)
            penw = _scale_penwidth(counts.get((src, tgt), 1))

            edge_color = "#7f8c8d"  # default gray
            if avg is not None and thr is not None and avg > thr:
                edge_color = "#e74c3c"  # red if above threshold

            dot.edge(s, t, xlabel=(lbl if lbl else None), penwidth=penw, color=edge_color)

        filename = f"{STATIC_DIR}/heuristics_performance"
        dot.render(filename, cleanup=True)
        return f"{filename}.png"

    else:
        # Frequency-based DFG using Heuristics Miner
        log = pm4py.format_dataframe(df_clean, case_id="case_id", activity_key="activity", timestamp_key="timestamp")

        params = {
            "min_dfg_occurrences": int(min_edge_freq),
            "dependency_thresh": 0.0,
            "and_threshold": 0.0,
            "loop_two_threshold": 0.0
        }
        heu_net = heu_miner.apply_heu(log, parameters=params)
        gviz = hn_vis.apply(heu_net, parameters={"format": "png"})
        filename = f"{STATIC_DIR}/heuristics_frequency.png"
        hn_vis.save(gviz, filename)
        return filename

# =========================================================
# ==================  SECTION: KPI LOGIC  =================
# =========================================================
def calculate_kpis(df):
    """
    Compute KPI:
    - average, max, min case durations (hours)
    - number of unique cases containing a 'Noshow' activity
    """
    if df.empty:
        return "0.00 h", "0.00 h", "0.00 h", 0

    df = df.copy()
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    case_durations = df.groupby('case_id')['timestamp'].agg(['min', 'max'])
    case_durations['duration'] = (case_durations['max'] - case_durations['min']).dt.total_seconds() / 3600.0

    avg_duration = f"{case_durations['duration'].mean():.2f} h" if not case_durations.empty else "0.00 h"
    max_duration = f"{case_durations['duration'].max():.2f} h" if not case_durations.empty else "0.00 h"
    min_duration = f"{case_durations['duration'].min():.2f} h" if not case_durations.empty else "0.00 h"

    noshow_cases = df[df['activity'].str.lower() == "noshow"]["case_id"].nunique()

    return avg_duration, max_duration, min_duration, noshow_cases

# =========================================================
# ==============  SECTION: THRESHOLD PAGE  ================
# =========================================================
@app.route("/threshold", methods=["GET", "POST"])
def threshold_page():
    variant = request.form.get("variant", "frequency")
    file_path = "data_updated.xlsx"

    # New: lightweight filters on Thresholds table (activity name / case id)
    activity_filter = (request.form.get("activity_filter") or "").strip()
    # case_filter = (request.form.get("case_filter") or "").strip()

    # Handle updating overrides from the form
    if request.method == "POST" and request.form.get("action") == "update_thresholds":
        srcs = request.form.getlist("src[]")
        tgts = request.form.getlist("tgt[]")
        thrs = request.form.getlist("thr[]")
        for s, t, v in zip(srcs, tgts, thrs):
            try:
                # Keep original labels; normalization will be handled at apply-time
                THRESHOLD_OVERRIDES[(s, t)] = float(v)
            except:
                pass
        save_overrides()  # Persist updates

    # Read min edge frequency (with session fallback)
    raw_mef = request.form.get("min_edge_freq")
    if raw_mef is not None and raw_mef != "":
        try:
            min_edge_freq = max(0, int(raw_mef))
        except Exception:
            min_edge_freq = session.get("min_edge_freq", 0)
    else:
        min_edge_freq = session.get("min_edge_freq", 0)
    session["min_edge_freq"] = min_edge_freq

    # Read Excel
    df = pd.read_excel(file_path)
    df = df.rename(columns={"CASEID": "case_id", "ACTIVITYNAME": "activity", "ACTIVITYTIME": "timestamp"})
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["case_id"] = df["case_id"].astype(str).str.strip()

    # Case selection (if any)
    selected_case = str(request.form.get("case_id", "all")).strip()
    df_filtered = df if selected_case == "all" else df[df["case_id"] == selected_case]

    # For single-case, show all edges (no frequency pruning)
    if selected_case != "all":
        min_edge_freq = 0

    # Filter by textual Case ID (optional, partial)
    # if case_filter:
    #     df_filtered = df_filtered[df_filtered["case_id"].str.contains(case_filter, case=False, na=False)]

    # Optionally hide Noshow from the visualization table source
    if HIDE_NOSHOW:
        df_filtered = _drop_noshow(df_filtered)

    # Build transitions then filter by min frequency
    activities, counts, avg_minutes, p75_map, edges = compute_transition_stats(df_filtered)
    filtered_edges = [e for e in edges if counts.get(e, 0) >= int(min_edge_freq)]

    # Filter by activity name (matches either src or tgt)
    if activity_filter:
        q = activity_filter.lower()
        def _m(a): return q in str(a).lower()
        filtered_edges = [e for e in filtered_edges if _m(e[0]) or _m(e[1])]

    # Build thresholds and robustly apply overrides
    thresholds = build_thresholds_for_all_edges(filtered_edges)
    thresholds = apply_overrides_to_thresholds(thresholds)  # <= ensure persisted overrides are applied

    DISPLAY_DECIMALS = 1
    edges_view = []
    for (src, tgt) in sorted(filtered_edges):
        thr_raw = float(thresholds.get((src, tgt), 0.0))
        thr = round(thr_raw, DISPLAY_DECIMALS)
        edges_view.append({"src": src, "tgt": tgt, "thr": thr})

    return render_template(
        "threshold.html",
        variant=variant,
        selected_case=selected_case,
        edges_view=edges_view,
        min_edge_freq=min_edge_freq,
        activity_filter=activity_filter,
        # case_filter=case_filter,
    )


@app.route("/", methods=["GET", "POST"])
def show_dfg():
    file_path = "data_updated.xlsx"

    # =========================
    # Variant selection (with session persistence)
    # =========================
    variant = request.form.get("variant")
    if variant:
        session["variant"] = variant
    else:
        variant = session.get("variant", "frequency")

    # =========================
    # Handle threshold updates
    # =========================
    if request.method == "POST" and request.form.get("action") == "update_thresholds":
        srcs = request.form.getlist("src[]")
        tgts = request.form.getlist("tgt[]")
        thrs = request.form.getlist("thr[]")
        for s, t, v in zip(srcs, tgts, thrs):
            try:
                THRESHOLD_OVERRIDES[(s, t)] = float(v)
            except:
                pass
        save_overrides()

    # =========================
    # Read min edge frequency (with session fallback)
    # =========================
    raw_mef = request.form.get("min_edge_freq")
    if raw_mef is not None and raw_mef != "":
        try:
            min_edge_freq = max(0, int(raw_mef))
        except Exception:
            min_edge_freq = session.get("min_edge_freq", 0)
        session["min_edge_freq"] = min_edge_freq
    else:
        min_edge_freq = session.get("min_edge_freq", 0)

    # =========================
    # Read Excel data
    # =========================
    df = pd.read_excel(file_path)
    df = df.rename(columns={"CASEID": "case_id", "ACTIVITYNAME": "activity", "ACTIVITYTIME": "timestamp"})
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["case_id"] = df["case_id"].astype(str).str.strip()

    # =========================
    # Prepare available dates
    # =========================
    all_dates = sorted(df["timestamp"].dropna().dt.date.astype(str).unique().tolist())

    # =========================
    # Read selected dates (persisted in session)
    # =========================
    raw_dates = request.form.getlist("dates[]")
    if raw_dates:
        selected_dates = [d for d in raw_dates if d in all_dates]
        session["selected_dates"] = selected_dates
    else:
        selected_dates = session.get("selected_dates", [])

    # Filter by selected dates
    if selected_dates:
        df = df[df["timestamp"].dt.date.astype(str).isin(selected_dates)]

    # =========================
    # Filter by case selection (with session persistence)
    # =========================
    selected_case = request.form.get("case_id")
    if selected_case:
        selected_case = str(selected_case).strip()
        session["selected_case"] = selected_case
    else:
        selected_case = session.get("selected_case", "all")

    df_filtered = df if selected_case == "all" else df[df["case_id"] == selected_case]

    # For single-case, disable frequency pruning
    if selected_case != "all":
        min_edge_freq = 0

    # =========================
    # Build df for model visualization (Noshow removed if enabled)
    # =========================
    df_for_model = _drop_noshow(df_filtered) if HIDE_NOSHOW else df_filtered

    # =========================
    # Generate DFG image
    # =========================
    sample_size = None
    image_file = generate_dfg_file(
        df_for_model,
        variant=variant,
        sample_size=sample_size,
        min_edge_freq=min_edge_freq,
        selected_case=selected_case
    )

    # =========================
    # KPIs from filtered df (Noshow NOT dropped)
    # =========================
    avg_case_duration, max_case_duration, min_case_duration, noshow_cases = calculate_kpis(df_filtered)

    # =========================
    # Edge stats for filtered edges (case-specific)
    # =========================
    activities_case, counts_case, _, _, edges_case = compute_transition_stats(df_for_model)
    filtered_edges = [e for e in edges_case if counts_case.get(e, 0) >= int(min_edge_freq)]

    # =========================
    # Compute avg_minutes on full dataset (all cases)
    # =========================
    df_full_model = _drop_noshow(df) if HIDE_NOSHOW else df
    _, _, avg_minutes_full, p75_map_full, _ = compute_transition_stats(df_full_model)

    # =========================
    # Thresholds
    # =========================
    thresholds = build_thresholds_for_all_edges(filtered_edges)
    thresholds = apply_overrides_to_thresholds(thresholds)

    # =========================
    # Build edges_view
    # =========================
    DISPLAY_DECIMALS = 1
    edges_view = []
    for (src, tgt) in sorted(filtered_edges):
        # Average across all cases (global reference)
        avg_raw = float(avg_minutes_full.get((src, tgt), 0.0))
        thr_raw = float(thresholds.get((src, tgt), 0.0))
        avg = round(avg_raw, DISPLAY_DECIMALS)
        thr = round(thr_raw, DISPLAY_DECIMALS)

        # ---- Δ vs Threshold (average vs threshold) ----
        diff_avg = avg - thr
        if diff_avg > 0:
            delta_symbol = "↑"; delta_sign = "+"; delta_color = "red"
        elif diff_avg < 0:
            delta_symbol = "↓"; delta_sign = "−"; delta_color = "green"
        else:
            delta_symbol = "→"; delta_sign = ""; delta_color = "gray"

        edge_item = {
            "src": src,
            "tgt": tgt,
            "avg": avg,
            "p75": round(float(p75_map_full.get((src, tgt), 0.0)), DISPLAY_DECIMALS),
            "thr": thr,
            "delta_abs": abs(diff_avg),
            "delta_symbol": delta_symbol,
            "delta_sign": delta_sign,
            "delta_color": delta_color,
        }

        # ---- Δ Case vs Threshold (case-specific time vs threshold) ----
        if selected_case != "all":
            df_case = df_filtered[df_filtered["case_id"] == selected_case].sort_values("timestamp")
            case_durations = {}
            for cid, g in df_case.groupby("case_id"):
                g = g.sort_values("timestamp")
                acts = g["activity"].tolist()
                times = g["timestamp"].tolist()
                for i in range(len(acts) - 1):
                    pair = (acts[i], acts[i+1])
                    duration = (times[i+1] - times[i]).total_seconds() / 60.0
                    case_durations[pair] = duration

            case_time = case_durations.get((src, tgt), None)
            if case_time is not None:
                diff_case = round(case_time - thr, DISPLAY_DECIMALS)
                if diff_case > 0:
                    case_symbol = "↑"; case_sign = "+"; case_color = "red"
                elif diff_case < 0:
                    case_symbol = "↓"; case_sign = "−"; case_color = "green"
                else:
                    case_symbol = "→"; case_sign = ""; case_color = "gray"

                edge_item["delta_case_abs"] = abs(diff_case)
                edge_item["delta_case_symbol"] = case_symbol
                edge_item["delta_case_sign"] = case_sign
                edge_item["delta_case_color"] = case_color
            else:
                edge_item["delta_case_abs"] = None
                edge_item["delta_case_symbol"] = ""
                edge_item["delta_case_sign"] = ""
                edge_item["delta_case_color"] = "gray"

        edges_view.append(edge_item)

    # =========================
    # Other stats
    # =========================
    num_cases = int(df_filtered["case_id"].nunique())
    avg_activities_per_case = df_filtered.groupby('case_id').size().mean()
    if pd.isna(avg_activities_per_case):
        avg_activities_per_case = 0.0
    case_list = df["case_id"].unique().tolist()

    # =========================
    # Render template
    # =========================
    return render_template(
        "filter.html",
        variant=variant,
        image_file=image_file,
        avg_case_duration=avg_case_duration,
        max_case_duration=max_case_duration,
        min_case_duration=min_case_duration,
        noshow_cases=noshow_cases,
        num_cases=num_cases,
        avg_activities_per_case=round(float(avg_activities_per_case), 2),
        case_list=case_list,
        selected_case=selected_case,
        edges_view=edges_view,
        min_edge_freq=min_edge_freq,
        all_dates=all_dates,
        selected_dates=selected_dates
    )


# =========================================================
# ====================  SECTION: MISC  ====================
# =========================================================
@app.route("/home")
def home():
    return redirect(url_for("show_dfg"))

@app.route('/departments')
def departments():
    return render_template('Departments.html')

@app.route('/chronic-care')
def chroniccare():
    return render_template('ChronicCare.html')

@app.route('/treatment-costs')
def treatmentcosts():
    return render_template('TreatmentCosts.html')

@app.route('/adherence-scale')
def adherencescale():
    return render_template('AdherenceScale.html')

@app.route('/smart-assistant')
def smartassistant():
    return render_template('SmartAssistant.html')

# =========================================================
# ====================  SECTION: RUN  =====================
# =========================================================
if __name__ == "__main__":
    app.run(debug=True, use_reloader=False, port=5008)
